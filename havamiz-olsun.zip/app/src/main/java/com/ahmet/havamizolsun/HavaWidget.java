package com.ahmet.havamizolsun;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

/** Ana ekran widget'ı: sıcaklık, durum, en yüksek / en düşük ve yağış ihtimali. */
public class HavaWidget extends AppWidgetProvider {

    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        ciz(c);
        HavaJob.kur(c);
        HavaJob.simdi(c);
    }

    static void ciz(Context c) {
        AppWidgetManager m = AppWidgetManager.getInstance(c);
        int[] ids = m.getAppWidgetIds(new ComponentName(c, HavaWidget.class));
        if (ids == null || ids.length == 0) return;
        SharedPreferences p = c.getSharedPreferences("hava", 0);
        RemoteViews v = new RemoteViews(c.getPackageName(), R.layout.widget);
        if (p.contains("w_t")) {
            v.setTextViewText(R.id.w_t, p.getInt("w_t", 0) + "°");
            v.setTextViewText(R.id.w_ad, p.getString("w_ad", ""));
            v.setTextViewText(R.id.w_k, p.getString("w_k", ""));
            v.setTextViewText(R.id.w_alt, "En yüksek " + p.getInt("w_mx", 0) + "° · En düşük " + p.getInt("w_mn", 0)
                    + "° · Yağış %" + p.getInt("w_y", 0));
        }
        v.setOnClickPendingIntent(R.id.w_kok, PendingIntent.getActivity(c, 0,
                new Intent(c, MainActivity.class), PendingIntent.FLAG_IMMUTABLE));
        m.updateAppWidget(ids, v);
    }
}
