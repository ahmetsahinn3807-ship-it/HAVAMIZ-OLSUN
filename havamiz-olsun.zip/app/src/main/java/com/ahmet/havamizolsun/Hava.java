package com.ahmet.havamizolsun;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Arka plan işleri: veri indirme, widget verisi, uyarı bildirimleri. */
class Hava {

    /** origin verilirse cevabın durum kodu da metne eklenir (MGM denemesi için). */
    static String indir(String adres, String origin) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(adres).openConnection();
        c.setConnectTimeout(10000);
        c.setReadTimeout(10000);
        c.setRequestProperty("Accept", "application/json");
        if (origin != null) {
            c.setRequestProperty("Origin", origin);
            c.setRequestProperty("Referer", origin + "/");
        }
        int kod = c.getResponseCode();
        InputStream in = kod >= 400 ? c.getErrorStream() : c.getInputStream();
        StringBuilder sb = new StringBuilder();
        if (in != null) {
            BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            char[] buf = new char[4096];
            int n;
            while ((n = r.read(buf)) > 0) sb.append(buf, 0, n);
            r.close();
        }
        c.disconnect();
        if (origin != null) return "HTTP " + kod + "\n" + sb;
        if (kod >= 400) throw new IOException("HTTP " + kod);
        return sb.toString();
    }

    static String adres(double lat, double lon) {
        return String.format(Locale.US, "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f"
                + "&current=temperature_2m,weather_code"
                + "&hourly=precipitation_probability"
                + "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,"
                + "precipitation_probability_max,wind_gusts_10m_max"
                + "&timezone=auto&forecast_days=2", lat, lon);
    }

    static String kosul(int c) {
        if (c == 0) return "Açık";
        if (c == 1) return "Az bulutlu";
        if (c == 2) return "Parçalı bulutlu";
        if (c == 3) return "Kapalı";
        if (c <= 48) return "Sisli";
        if (c <= 57) return "Çisenti";
        if (c <= 67) return "Yağmurlu";
        if (c <= 77) return "Karlı";
        if (c <= 82) return "Sağanak yağışlı";
        if (c <= 86) return "Kar sağanağı";
        return "Gök gürültülü fırtına";
    }

    static void guncelle(Context ctx) throws Exception {
        SharedPreferences p = ctx.getSharedPreferences("hava", 0);
        String ad = p.getString("ad", "İstanbul");
        double lat = p.getFloat("lat", 41.01f), lon = p.getFloat("lon", 28.98f);

        JSONObject j = new JSONObject(indir(adres(lat, lon), null));
        JSONObject cur = j.getJSONObject("current"), d = j.getJSONObject("daily");
        p.edit().putString("w_ad", ad)
                .putInt("w_t", (int) Math.round(cur.getDouble("temperature_2m")))
                .putString("w_k", kosul(cur.optInt("weather_code", 0)))
                .putInt("w_mx", (int) Math.round(d.getJSONArray("temperature_2m_max").getDouble(0)))
                .putInt("w_mn", (int) Math.round(d.getJSONArray("temperature_2m_min").getDouble(0)))
                .putInt("w_y", (int) Math.round(d.getJSONArray("precipitation_probability_max").optDouble(0, 0)))
                .apply();
        HavaWidget.ciz(ctx);

        List<String> metin = new ArrayList<>();
        Set<String> anahtar = new HashSet<>();
        uyarilar(ad, j, true, metin, anahtar);
        if (p.contains("ilat")) {
            try {
                JSONObject k = new JSONObject(indir(adres(p.getFloat("ilat", 0), p.getFloat("ilon", 0)), null));
                uyarilar(p.getString("iad", "İşaretli bölge"), k, false, metin, anahtar);
            } catch (Exception e) {
                // işaretli bölge alınamadıysa yalnızca konum uyarıları gösterilir
            }
        }

        // Yalnızca daha önce bildirilmemiş bir uyarı varsa bildirim gönder
        Set<String> eski = p.getStringSet("uyari", new HashSet<String>());
        boolean yeni = false;
        for (String a : anahtar) if (!eski.contains(a)) yeni = true;
        p.edit().putStringSet("uyari", anahtar).apply();
        if (yeni) bildir(ctx, metin);
    }

    private static double sayi(JSONObject d, String ad, int i) {
        JSONArray a = d.optJSONArray(ad);
        return a == null ? Double.NaN : a.optDouble(i, Double.NaN);
    }

    /** Sayfadaki Uyarılar sekmesiyle aynı eşikler; bugün ve yarın için. */
    static void uyarilar(String ad, JSONObject j, boolean yagmurYakin, List<String> metin, Set<String> anahtar)
            throws Exception {
        JSONObject d = j.getJSONObject("daily");
        JSONArray gunler = d.getJSONArray("time");
        String[] seviye = {"", "Sarı", "Turuncu", "Kırmızı"};
        for (int i = 0; i < 2 && i < gunler.length(); i++) {
            String gun = i == 0 ? "Bugün" : "Yarın", tarih = gunler.getString(i);
            double y = sayi(d, "precipitation_sum", i), r = sayi(d, "wind_gusts_10m_max", i);
            double mn = sayi(d, "temperature_2m_min", i), mx = sayi(d, "temperature_2m_max", i);
            double kodu = sayi(d, "weather_code", i);
            int c = Double.isNaN(kodu) ? 0 : (int) kodu;
            if (y >= 20) {
                int s = y >= 100 ? 3 : y >= 50 ? 2 : 1;
                metin.add(ad + " · " + gun + ": Kuvvetli yağış (" + seviye[s] + "), toplam " + Math.round(y) + " mm");
                anahtar.add(ad + tarih + "yagis" + s);
            }
            if (r >= 50) {
                int s = r >= 100 ? 3 : r >= 75 ? 2 : 1;
                metin.add(ad + " · " + gun + ": Kuvvetli rüzgâr (" + seviye[s] + "), hamle " + Math.round(r) + " km/sa");
                anahtar.add(ad + tarih + "ruzgar" + s);
            }
            if (mn <= 0) {
                int s = mn <= -10 ? 2 : 1;
                metin.add(ad + " · " + gun + ": Don (" + seviye[s] + "), en düşük " + Math.round(mn) + "°");
                anahtar.add(ad + tarih + "don" + s);
            }
            if (mx >= 35) {
                int s = mx >= 40 ? 2 : 1;
                metin.add(ad + " · " + gun + ": Aşırı sıcak (" + seviye[s] + "), en yüksek " + Math.round(mx) + "°");
                anahtar.add(ad + tarih + "sicak" + s);
            }
            if (c >= 95) {
                metin.add(ad + " · " + gun + ": Gök gürültülü fırtına (Sarı)");
                anahtar.add(ad + tarih + "firtina");
            } else if ((c >= 71 && c <= 77) || c == 85 || c == 86) {
                metin.add(ad + " · " + gun + ": Kar yağışı (Sarı)");
                anahtar.add(ad + tarih + "kar");
            }
        }
        if (!yagmurYakin) return;
        // Önümüzdeki 3 saatte yağış ihtimali yüksekse şemsiye hatırlatması
        JSONObject h = j.getJSONObject("hourly");
        JSONArray zaman = h.getJSONArray("time"), olasilik = h.getJSONArray("precipitation_probability");
        String simdi = j.getJSONObject("current").getString("time");
        if (simdi.length() < 13) return;
        simdi = simdi.substring(0, 13);
        for (int i = 0; i < zaman.length(); i++) {
            if (!zaman.getString(i).startsWith(simdi)) continue;
            double enCok = 0;
            for (int k = i; k < i + 3 && k < olasilik.length(); k++) enCok = Math.max(enCok, olasilik.optDouble(k, 0));
            if (enCok >= 60) {
                metin.add(0, ad + ": 3 saat içinde yağış bekleniyor (%" + Math.round(enCok) + "). Şemsiyeni al.");
                // aynı gün için 6 saatlik dilim başına en fazla bir hatırlatma
                anahtar.add(ad + simdi.substring(0, 10) + "yagmur" + (Integer.parseInt(simdi.substring(11, 13)) / 6));
            }
            break;
        }
    }

    static void bildir(Context ctx, List<String> metin) {
        if (metin.isEmpty()) return;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        nm.createNotificationChannel(new NotificationChannel("uyari", "Hava uyarıları",
                NotificationManager.IMPORTANCE_DEFAULT));
        StringBuilder hepsi = new StringBuilder();
        for (String m : metin) {
            if (hepsi.length() > 0) hepsi.append("\n");
            hepsi.append(m);
        }
        PendingIntent ac = PendingIntent.getActivity(ctx, 0, new Intent(ctx, MainActivity.class),
                PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(ctx, "uyari")
                .setSmallIcon(R.drawable.ic_bildirim)
                .setContentTitle("Hava uyarısı")
                .setContentText(metin.get(0))
                .setStyle(new Notification.BigTextStyle().bigText(hepsi.toString()))
                .setContentIntent(ac)
                .setAutoCancel(true)
                .build();
        nm.notify(1, n);
    }
}
