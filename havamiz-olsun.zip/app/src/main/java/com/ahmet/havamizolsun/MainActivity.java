package com.ahmet.havamizolsun;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MainActivity extends Activity {
    static final String TABAN = "https://havamizolsun.app/";
    private WebView web;
    private GeolocationPermissions.Callback konumCevap;
    private String konumKaynak;
    private boolean izinBekliyor = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setGeolocationEnabled(true);
        web.addJavascriptInterface(new Kopru(), "Android");

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                String adres = u.toString();
                if (adres.startsWith(TABAN)) return false;
                String host = u.getHost();
                if (host != null && host.endsWith("mgm.gov.tr")) {
                    startActivity(new Intent(MainActivity.this, MgmActivity.class).putExtra("url", adres));
                    return true;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception e) {
                    // açacak uygulama yoksa bir şey yapma
                }
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String kaynak, GeolocationPermissions.Callback cevap) {
                if (konumIzniVar()) {
                    cevap.invoke(kaynak, true, false);
                } else if (izinBekliyor) {
                    konumCevap = cevap;
                    konumKaynak = kaynak;
                } else {
                    cevap.invoke(kaynak, false, false);
                }
            }
        });

        // Konum ve bildirim izinlerini tek seferde iste
        ArrayList<String> eksik = new ArrayList<>();
        if (!konumIzniVar()) {
            eksik.add(Manifest.permission.ACCESS_FINE_LOCATION);
            eksik.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            eksik.add(Manifest.permission.POST_NOTIFICATIONS);
        }
        if (!eksik.isEmpty()) {
            izinBekliyor = true;
            requestPermissions(eksik.toArray(new String[0]), 1);
        }

        web.loadDataWithBaseURL(TABAN, sayfayiOku(), "text/html", "UTF-8", null);
        HavaJob.kur(this);
    }

    private boolean konumIzniVar() {
        return checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int kod, String[] izinler, int[] sonuc) {
        super.onRequestPermissionsResult(kod, izinler, sonuc);
        izinBekliyor = false;
        boolean var = konumIzniVar();
        if (konumCevap != null) {
            konumCevap.invoke(konumKaynak, var, false);
            konumCevap = null;
        }
        // İzin verildiyse sayfa konumu yeniden denesin
        if (var) web.evaluateJavascript("window.yukle&&yukle()", null);
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    private String sayfayiOku() {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader(getAssets().open("index.html"), "UTF-8"))) {
            char[] buf = new char[8192];
            int n;
            while ((n = r.read(buf)) > 0) sb.append(buf, 0, n);
        } catch (Exception e) {
            return "<p>Sayfa okunamadı.</p>";
        }
        return sb.toString();
    }

    /** Sayfanın telefona haber verdiği köprü. */
    class Kopru {
        @JavascriptInterface
        public void kaydet(String ad, double lat, double lon) {
            getSharedPreferences("hava", 0).edit()
                    .putString("ad", ad).putFloat("lat", (float) lat).putFloat("lon", (float) lon).apply();
            HavaJob.simdi(MainActivity.this);
        }

        @JavascriptInterface
        public void isaret(String ad, double lat, double lon) {
            getSharedPreferences("hava", 0).edit()
                    .putString("iad", ad).putFloat("ilat", (float) lat).putFloat("ilon", (float) lon).apply();
        }

        @JavascriptInterface
        public void mgmDene() {
            new Thread(() -> {
                String sonuc;
                try {
                    sonuc = Hava.indir("https://servis.mgm.gov.tr/web/meteoalarm/today", "https://www.mgm.gov.tr");
                } catch (Exception e) {
                    sonuc = "HATA: " + e;
                }
                if (sonuc.length() > 1500) sonuc = sonuc.substring(0, 1500) + "\n… (devamı kesildi)";
                final String js = "window.mgmSonuc&&mgmSonuc(" + JSONObject.quote(sonuc) + ")";
                runOnUiThread(() -> web.evaluateJavascript(js, null));
            }).start();
        }
    }
}
